//
//  ActivityView.swift
//  Circle5
//
//  Created by Maryam Hina on 2025-02-22.
//

import SwiftUI

struct ActivityView: View {
    var body: some View {
        Text("Activity")
    }
}

#Preview {
    ActivityView()
}
