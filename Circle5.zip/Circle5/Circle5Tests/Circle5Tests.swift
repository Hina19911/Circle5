//
//  Circle5Tests.swift
//  Circle5Tests
//
//  Created by Maryam Hina on 2025-02-14.
//

import Testing
@testable import Circle5

struct Circle5Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
